CONSTRUIRE L'APK (sans Android Studio, gratuit)

1. Creer un compte sur github.com puis un nouveau depot (New repository), par exemple "humidite".
2. Dans le depot : Add file > Upload files. Glisser TOUT le contenu de ce dossier
   (www, package.json, capacitor.config.json, .gitignore, .github) puis Commit.
   Si le dossier ".github" n'apparait pas dans le depot : Add file > Create new file,
   taper le nom  .github/workflows/build-apk.yml  et coller le contenu de build-apk.yml.txt.
3. Onglet Actions > "Build APK" > Run workflow. Attendre environ 5 minutes (coche verte).
4. Ouvrir l'execution terminee > section Artifacts > telecharger "humidite-apk" (zip contenant app-debug.apk).
5. Copier app-debug.apk sur le telephone Android et l'ouvrir.
   Autoriser "Installer des applications inconnues" si Android le demande.

Pour modifier l'application plus tard : remplacer www/index.html dans le depot,
l'APK se reconstruit automatiquement.
